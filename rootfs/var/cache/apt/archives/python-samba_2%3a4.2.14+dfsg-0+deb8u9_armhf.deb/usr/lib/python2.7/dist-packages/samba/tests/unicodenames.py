# Copyright (C) 2003 by Martin Pool <mbp@samba.org>

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

"""
Defines symbolic names for a few UNICODE characters, to make test
source code more readable on machines that don't have all the
necessary fonts.

You can do "import *" on this file safely.
"""

LATIN_CAPITAL_LETTER_N_WITH_TILDE         = u'\u004e'
LATIN_CAPITAL_LETTER_O_WITH_DIARESIS      = u'\u00d6'
LATIN_SMALL_LETTER_O_WITH_DIARESIS        = u'\u00f6'

KATAKANA_LETTER_A                         = u'\u30a2'
