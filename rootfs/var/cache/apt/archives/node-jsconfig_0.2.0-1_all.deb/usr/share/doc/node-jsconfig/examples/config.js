
module.exports = {
    type: "production",
};
